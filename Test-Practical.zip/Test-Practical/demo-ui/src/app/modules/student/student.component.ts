import { Component, OnInit, TemplateRef } from '@angular/core';
import { StudentService } from 'src/app/core/service/student.service';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Student } from 'src/app/model/student';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.scss']
})
export class StudentComponent implements OnInit {

  dataSource = new MatTableDataSource();
  displayedColumns = ['fname','lname','city','action'];
  isUpdate: boolean = false;

  studentForm: FormGroup = new FormGroup({});

  constructor(
    private studentService: StudentService,
    private matDialog: MatDialog,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    this.studentForm = this.formBuilder.group({
      id: new FormControl(''),
      fName: new FormControl('',[Validators.required]),
      lName: new FormControl('',[Validators.required]),
      city: new FormControl('',[Validators.required])
    });
    this.getAllStudent();
  }

  private setFormData(obj: any) {
    this.studentForm.controls['fName'].setValue(obj?.fName);
    this.studentForm.controls['id'].setValue(obj?.id);
    this.studentForm.controls['lName'].setValue(obj?.lName);
    this.studentForm.controls['city'].setValue(obj?.city);
  }

  openDialog(dialog: TemplateRef<any>, dataObj?: any) {
    this.isUpdate = dataObj ? true : false;
    this.studentForm.reset();
    if(dataObj) {
      this.setFormData(dataObj);
    }
    this.matDialog.open(dialog, {
      autoFocus: false,
      closeOnNavigation: true,
      disableClose: true
    });
  }

  createStudent() {
    if(this.studentForm.invalid) {
      this.studentForm.markAllAsTouched();
      return;
    }
    const studentObj: Student = {
      lName: this.studentForm.controls['lName'].value,
      fName: this.studentForm.controls['fName'].value,
      city: this.studentForm.controls['city'].value
    }
    if(this.isUpdate) {
      studentObj['id'] = this.studentForm.controls['id'].value;
      this.updateStudent(studentObj);
    } else {
      this.saveStudent(studentObj);  
    }
  }

  private updateStudent(student: Student) {
    this.studentService.updateStduentData(student).subscribe((reponse: any) => {
      this.matDialog.closeAll();
      this.getAllStudent();
    });
  }

  private saveStudent(student: Student) {
    this.studentService.saveStduentData(student).subscribe((response: any) => {
      this.matDialog.closeAll();
      this.getAllStudent();
    });
  }

  getAllStudent() {
    this.studentService.getAllStudent().subscribe((response: any) => {
      this.dataSource.data = response;
    },
    (error: any) => {

    });
  }

  deleteStduent(obj: any) {
    const id = obj?.id;
    if(id) {
      this.studentService.deleteStduent(id).subscribe((response: any) => {
        this.getAllStudent();
      });
    }
  }
}
