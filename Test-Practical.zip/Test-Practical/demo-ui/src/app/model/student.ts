export interface Student {
    id?: number;
    fName: string;
    lName: string;
    city: string;
}