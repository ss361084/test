import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Student } from '../../model/student';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  origin = environment.origin;

  constructor(
    private httpClient: HttpClient
  ) { }

  getAllStudent() {
    return this.httpClient.get(`${this.origin}/api/student`);
  }

  saveStduentData(student: Student) {
    return this.httpClient.post(`${this.origin}/api/student`,student);
  }

  updateStduentData(student: Student) {
    return this.httpClient.put(`${this.origin}/api/student`,student);
  }

  deleteStduent(id: number) {
    return this.httpClient.delete(`${this.origin}/api/student/${id}`);
  }
}
