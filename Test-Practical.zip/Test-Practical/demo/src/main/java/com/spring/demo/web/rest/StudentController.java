package com.spring.demo.web.rest;

import com.spring.demo.service.StudentService;
import com.spring.demo.service.dto.StudentDto;
import com.spring.demo.service.exception.StudentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/api/")
public class StudentController {
    private static final Logger log = LoggerFactory.getLogger(StudentController.class);
    @Autowired
    private StudentService studentService;

    @PostMapping("student")
    public ResponseEntity<StudentDto> saveStudent(@Valid @RequestBody StudentDto studentDto) throws URISyntaxException {
        log.debug("Rest Request to Save Student");
        if (studentDto.getId() != null) {
            throw new StudentException("Id Found while Saving Student");
        }
        StudentDto result = studentService.save(studentDto);
        return ResponseEntity.created(new URI("/api/student"+result.getId()))
                .body(result);
    }

    @PutMapping("student")
    public ResponseEntity<StudentDto> updateStudent(@Valid @RequestBody StudentDto studentDto) throws URISyntaxException {
        log.debug("Rest Request to Update Student");
        if (studentDto.getId() == null) {
            throw new StudentException("Id Not Found while Update Student");
        }
        StudentDto result = studentService.save(studentDto);
        return ResponseEntity.ok(result);
    }

    @GetMapping("student")
    public ResponseEntity<List<StudentDto>> getAllStudents() {
        log.debug("Rest request to Get All Students");
        List<StudentDto> studentDtoList = studentService.findAll();
        return ResponseEntity.ok(studentDtoList);
    }

    @GetMapping("student/{id}")
    public ResponseEntity<StudentDto> getStudent(@PathVariable("id") Long id) {
        log.debug("Rest request to Get Student By Id : {0}", id);
        if (Objects.isNull(id)) {
            throw new StudentException("Id Not found while Fetching Student By Id");
        }
        Optional<StudentDto> studentDto = studentService.findById(id);
        if (studentDto.isPresent()) {
            return ResponseEntity.ok(studentDto.get());
        } else {
            throw new StudentException("Student Not Found with Id : "+id);
        }
    }

    @DeleteMapping("student/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable("id") Long id) {
        log.debug("Rest request to Delete Student By Id : {0}", id);
        if (Objects.isNull(id)) {
            throw new StudentException("Id Not found while Delete Student By Id");
        }
        Optional<StudentDto> studentDto = studentService.findById(id);
        if (studentDto.isPresent()) {
            studentService.deleteStudentById(id);
            return ResponseEntity.noContent().build();
        } else {
            throw new StudentException("Student Not Found with Id : "+id);
        }
    }
}
