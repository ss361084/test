package com.spring.demo.service;

import com.spring.demo.service.dto.StudentDto;

import java.util.List;
import java.util.Optional;

public interface StudentService {
    StudentDto save(StudentDto studentDto);
    List<StudentDto> findAll();
    Optional<StudentDto> findById(Long id);

    void deleteStudentById(Long id);
}
