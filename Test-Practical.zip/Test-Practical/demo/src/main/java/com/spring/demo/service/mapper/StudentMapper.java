package com.spring.demo.service.mapper;

import com.spring.demo.entity.Student;
import com.spring.demo.service.dto.StudentDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface StudentMapper extends EntityMapper<StudentDto, Student> {
}
