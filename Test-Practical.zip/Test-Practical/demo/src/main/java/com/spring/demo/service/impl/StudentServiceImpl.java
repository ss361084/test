package com.spring.demo.service.impl;

import com.spring.demo.entity.Student;
import com.spring.demo.repository.StudentRepository;
import com.spring.demo.service.StudentService;
import com.spring.demo.service.dto.StudentDto;
import com.spring.demo.service.mapper.StudentMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
    private static final Logger log = LoggerFactory.getLogger(StudentServiceImpl.class);
    private StudentRepository studentRepository;
    private StudentMapper studentMapper;

    StudentServiceImpl(StudentRepository studentRepository,StudentMapper studentMapper) {
        this.studentRepository = studentRepository;
        this.studentMapper = studentMapper;
    }

    @Override
    public StudentDto save(StudentDto studentDto) {
        log.debug("Request to Save Student");
        Student student = studentMapper.toEntity(studentDto);
        student = studentRepository.save(student);
        return studentMapper.toDto(student);
    }

    @Override
    public List<StudentDto> findAll() {
        log.debug("Request to Find All Student");
        return studentRepository.findAll().stream()
                .map(studentMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<StudentDto> findById(Long id) {
        log.debug("Request to Find Student By Id : {0}", id);
        return studentRepository.findById(id).map(studentMapper::toDto);
    }

    @Override
    public void deleteStudentById(Long id) {
        log.debug("Request to Delete Student By Id : {0}", id);
        studentRepository.deleteById(id);
    }
}
