package com.spring.demo.service.exception;

public class StudentException extends RuntimeException {
    public StudentException(String message) {
        super(message);
    }
}
