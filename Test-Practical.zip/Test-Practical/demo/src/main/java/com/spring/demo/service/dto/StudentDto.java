package com.spring.demo.service.dto;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

public class StudentDto implements Serializable {
    public static final long serialVersionUID = 1L;
    private Long id;
    @NotBlank(message = "provide First Name")
    private String fName;
    @NotBlank(message = "Provide Last Name")
    private String lName;
    @NotBlank(message = "Provide City")
    private String city;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "StudentDto{" +
                "id=" + id +
                ", fName='" + fName + '\'' +
                ", lName='" + lName + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
